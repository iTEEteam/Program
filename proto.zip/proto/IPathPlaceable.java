package proto;






public interface IPathPlaceable {
	public void eliminate();
	public void registerPath(Path p);
}
