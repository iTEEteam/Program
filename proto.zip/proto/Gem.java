package proto;



public abstract class Gem {
	/**
	 * A kristaly ara. Statikus, mert minden kristaly ugyanannyiba kerul.
	**/
	public static int price = 10;
	
//	/**
//	 * Konstruktor
//	 *
//	 * @param    price
//	**/
//
//	public Gem() {
//	
//	}

}
