package proto;




public interface IOGem {
	public void upgradeObstacle(Obstacle o);
}
