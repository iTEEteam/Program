package graph;




public interface IOGem {
	public void upgradeObstacle(Obstacle o);
}
