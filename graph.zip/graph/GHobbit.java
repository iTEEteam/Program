package graph;

/**
 * A Hobbit kirajzol�s��rt felel�s oszt�ly. 
 * 
 * @author Seres
 *
 */
public class GHobbit extends GEnemy {

	public GHobbit(Enemy e) {
		super(e);
	}

	@Override
	public void drawMe(GPath gp) {
		gp.drawGHobbit();
	}

}
