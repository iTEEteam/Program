package graph;




public interface ITGem {
	public void upgradeTower(Tower t);
	public int getValue();
}
