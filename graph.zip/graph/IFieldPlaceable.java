package graph;




public interface IFieldPlaceable {
	public void registerField(Field field);
	public void sell();
}
